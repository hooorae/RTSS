let myMesh;


function createEnvironment(scene) {
  console.log("Adding environment");
  
  // for (let i = 0; i < 10; i++){
  //   let texture = new THREE.TextureLoader().load("../assets/texture.png");
  //   ////create balls basic shapes
  //   // let myGeometry = new THREE.SphereGeometry(3, 12, 12);
  //   // let myMaterial = new THREE.MeshBasicMaterial({ map: texture });
  //   // myMesh = new THREE.Mesh(myGeometry, myMaterial);

  //   let myGeometry = new THREE.BoxGeometry( 3, 10, 10 ); //（x横，y高，z长）
  //   let myMaterial = new THREE.MeshBasicMaterial( { map: texture } );
  //   let myMesh = new THREE.Mesh(myGeometry, myMaterial);
  
  //   myMesh.position.set(i*4, 1.5, 10); //括号里数字依次为：x距离，y距离，z距离
  // scene.add(myMesh);
  // }
  scene.background = new THREE.Color( "rgb(0,0,0)" );

  let texture = new THREE.TextureLoader().load("../assets/face.jpeg");
  let myGeometry = new THREE.BoxGeometry( 10, 4, 5 ); //（x横，y高，z长）
  let myMaterial = new THREE.MeshBasicMaterial( { map: texture } );
  let myMesh = new THREE.Mesh(myGeometry, myMaterial);
  myMesh.position.set(0, 2, 10); //括号里数字依次为：x距离，y距离，z距离
  scene.add(myMesh);


  let texture1 = new THREE.TextureLoader().load("../assets/face1.jpg");
  let myGeometry1 = new THREE.BoxGeometry( 10, 8, 5 ); //（x横，y高，z长）
  let myMaterial1 = new THREE.MeshBasicMaterial( { map: texture1 } );
  let myMesh1 = new THREE.Mesh(myGeometry1, myMaterial1);
  myMesh1.position.set(-10, 8, -10); 
  scene.add(myMesh1);

  let texture2 = new THREE.TextureLoader().load("../assets/face2.jpg");
  let myGeometry2 = new THREE.BoxGeometry( 10, 8, 5 ); //（x横，y高，z长）
  let myMaterial2 = new THREE.MeshBasicMaterial( { map: texture2 } );
  let myMesh2 = new THREE.Mesh(myGeometry2, myMaterial2);
  myMesh2.position.set(10, 4, -16); 
  scene.add(myMesh2);

  let texture3 = new THREE.TextureLoader().load("../assets/face3.jpeg");
  let myGeometry3 = new THREE.BoxGeometry(10, 5, 5 ); //（x横，y高，z长）
  let myMaterial3 = new THREE.MeshBasicMaterial( { map: texture3 } );
  let myMesh3 = new THREE.Mesh(myGeometry3, myMaterial3);
  myMesh3.position.set(-10, -2, -20); 
  scene.add(myMesh3);

  let texture4 = new THREE.TextureLoader().load("../assets/face4.jpeg");
  let myGeometry4 = new THREE.BoxGeometry(10, 5, 10 ); //（x横，y高，z长）
  let myMaterial4 = new THREE.MeshBasicMaterial( { map: texture4 } );
  let myMesh4 = new THREE.Mesh(myGeometry4, myMaterial4);
  myMesh4.position.set(-30, 2.5, -5); 
  scene.add(myMesh4);

  let texture5 = new THREE.TextureLoader().load("../assets/face5.jpg");
  let myGeometry5 = new THREE.BoxGeometry(20, 10, 20 ); //（x横，y高，z长）
  let myMaterial5 = new THREE.MeshBasicMaterial( { map: texture5 } );
  let myMesh5 = new THREE.Mesh(myGeometry5, myMaterial5);
  myMesh5.position.set(-50, 10, 15); 
  scene.add(myMesh5);

  let texture6 = new THREE.TextureLoader().load("../assets/face6.jpg");
  let myGeometry6 = new THREE.BoxGeometry(20, 20, 20 ); //（x横，y高，z长）
  let myMaterial6 = new THREE.MeshBasicMaterial( { map: texture6 } );
  let myMesh6 = new THREE.Mesh(myGeometry6, myMaterial6);
  myMesh6.position.set(50, -2, 10); 
  scene.add(myMesh6);

  let texture7 = new THREE.TextureLoader().load("../assets/face7.jpg");
  let myGeometry7 = new THREE.BoxGeometry(10, 5, 5 ); //（x横，y高，z长）
  let myMaterial7 = new THREE.MeshBasicMaterial( { map: texture7 } );
  let myMesh7 = new THREE.Mesh(myGeometry7, myMaterial7);
  myMesh7.position.set(-10, -2, -20); 
  scene.add(myMesh7);
}



function updateEnvironment(scene) {
  // myMesh.position.x += 0.01;
}

